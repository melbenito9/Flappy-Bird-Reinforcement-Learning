
#Template for SARSA.


class FBSample(object):
    
    def __init__(self, Act):
        self.Act = Act

    def act(self, State):
        raise NotImplementedError("Override this.")
    
    def train(self, Iterations):
        raise NotImplementedError("Override this.")
    
    def test(self, Iterations):
        raise NotImplementedError("Override this.")
        
    def saveOutput(self):
        raise NotImplementedError("Override this.")